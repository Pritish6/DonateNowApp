package com.drivertest.donatenowapp.Service

import com.drivertest.donatenowapp.Model.UserResponse

import io.reactivex.Single
import retrofit2.http.*

interface UserApi {

    @GET(".")
    fun getUser(@Query("results")key:Int): Single<UserResponse>
    // suspend fun getMovie(@Path("movie_id") id: Int) : Response<MovieDesc>
}