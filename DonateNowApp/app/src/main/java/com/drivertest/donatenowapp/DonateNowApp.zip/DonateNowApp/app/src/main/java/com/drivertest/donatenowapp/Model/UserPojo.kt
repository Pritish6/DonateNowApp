package com.drivertest.donatenowapp.Model

import android.os.Parcel
import android.os.Parcelable
import androidx.annotation.NonNull
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "userpojo")
data class UserPojo(

    @PrimaryKey(autoGenerate = true)
    val id: Int,
        @Embedded
        val name:NamePojo?)


