package com.drivertest.donatenowapp.Repository

import com.drivertest.donatenowapp.Model.UserResponse
import com.drivertest.donatenowapp.Service.ApiService
import com.drivertest.donatenowapp.UserDao


import io.reactivex.Single
import javax.inject.Inject

class UserRepository @Inject constructor(private val userDao: UserDao) {

    @Inject
    lateinit var apiService: ApiService

    init {
   //     DaggerApiComponent.create().inject(this)
    }
// public Observable<PokemonResponse> getPokemons(){
//        return apiService.getPokemons();
//    }
fun getUserRepo(key : Int):Single<UserResponse>{return apiService.getUser(key)}
}