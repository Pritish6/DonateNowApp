package com.drivertest.donatenowapp

import android.app.Application


import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.bumptech.glide.Glide.init
import com.drivertest.donatenowapp.Model.UserResponse
import com.drivertest.donatenowapp.Repository.UserRepository
import com.drivertest.donatenowapp.Service.ApiService

import dagger.hilt.android.lifecycle.HiltViewModel


import io.reactivex.Scheduler
import io.reactivex.SingleObserver
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import io.reactivex.observers.DisposableSingleObserver
import io.reactivex.schedulers.Schedulers
import javax.inject.Inject
@HiltViewModel
class ListViewModel ( ): ViewModel() {
    private lateinit var repoService: UserRepository

    @Inject
    constructor(repository: UserRepository) : this() {
        this.repoService = repository
    }

    val users by lazy {MutableLiveData<UserResponse>()}
    val loadError by lazy {MutableLiveData<Boolean>()}
    val loading by lazy {MutableLiveData<Boolean>()}

    @Inject
    lateinit var apiService: ApiService

    init {
     //   DaggerApiComponent.create().inject(this)
    }
    fun refresh(){
        loading.value=true
getUsers()
    }

    private val disposable = CompositeDisposable()

    private fun getUsers() {
        disposable.add(repoService.getUserRepo(10).subscribeOn(Schedulers.newThread()).observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(object :DisposableSingleObserver<UserResponse>(){
                    override fun onSuccess(mlist: UserResponse) {
                        loadError.value=false
                        users.value= mlist
                        loading.value=false
                    }

                    override fun onError(e: Throwable) {
                        loading.value=false
                        users.value=null
                        loadError.value=true
                    }
                }))

    }

    override fun onCleared() {
        super.onCleared()
        disposable.clear()
    }

}

