package com.drivertest.donatenowapp

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.drivertest.donatenowapp.Model.UserPojo



@Database(entities = [UserPojo::class], version = 1,exportSchema = false)
@TypeConverters(GenreConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
}