package com.drivertest.donatenowapp.Service




import com.drivertest.donatenowapp.Model.UserResponse
import io.reactivex.Single
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Inject

class ApiService {

    @Inject
    lateinit var api:UserApi
    //private val api = Retrofit.Builder().baseUrl("https://us-central1-apis-4674e.cloudfunctions.net").addConverterFactory(GsonConverterFactory.create())
     //   .addCallAdapterFactory(RxJava2CallAdapterFactory.create()).build().create(Animalapi::class.java)

    init{
  //      DaggerApiComponent.create().inject(this)
    }


    fun getUser(key : Int):Single<UserResponse>{return api.getUser(key)}
}