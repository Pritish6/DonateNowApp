package com.drivertest.donatenowapp.DI

import com.drivertest.donatenowapp.ApiModule
import com.drivertest.donatenowapp.ListViewModel
import com.drivertest.donatenowapp.Repository.UserRepository
import com.drivertest.donatenowapp.Service.ApiService



import dagger.Component

@Component(modules = [ApiModule::class])
interface ApiComponent {
    fun inject(service: ApiService)
    fun inject(viewModel: ListViewModel)
    fun inject(viewModel: UserRepository)
}