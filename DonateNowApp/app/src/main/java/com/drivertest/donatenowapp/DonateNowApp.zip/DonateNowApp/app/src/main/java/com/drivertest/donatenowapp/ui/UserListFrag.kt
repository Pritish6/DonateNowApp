package com.drivertest.donatenowapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory
import androidx.recyclerview.widget.GridLayoutManager
import com.drivertest.donatenowapp.ListViewModel
import com.drivertest.donatenowapp.Model.User
import com.drivertest.donatenowapp.Model.UserResponse
import com.drivertest.donatenowapp.UserListAdapter
import com.drivertest.donatenowapp.databinding.FragmentUserListBinding

import dagger.hilt.android.AndroidEntryPoint


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


@AndroidEntryPoint
class UserListFrag : Fragment() {
    // TODO: Rename and change types of parameters
    // TODO: Rename and change types of parameters
    private var _binding: FragmentUserListBinding? = null
    private val binding get() = _binding!!
   val viewModel by viewModels<ListViewModel>()
  //  private lateinit var viewModel: ListViewModel
    private val listAdapter = UserListAdapter(arrayListOf<User>())
    private val animalListDataObserver = Observer<UserResponse> { list-> list?.let { binding.userList.visibility=View.VISIBLE;listAdapter.updateUserList(
        it.results
    ) }}
    private val loadingDataObserver = Observer<Boolean> { isLoading ->
        binding.listViewProgressBar.visibility =if(isLoading) View.VISIBLE else View.GONE
        if(isLoading){
            binding.listError.visibility= View.GONE
            binding.userList.visibility=View.GONE
        }
    }
    private val errorObserver = Observer<Boolean> { isError ->
        binding.listError.visibility = if(isError) View.VISIBLE else View.GONE

    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentUserListBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
        // return inflater.inflate(R.layout.fragment_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
     //   viewModel = ViewModelProvider(this).get(ListViewModel::class.java)
//viewModel = ViewModelProvider(
//    this,
//    AndroidViewModelFactory(requireActivity().application)
//)[ListViewModel::class.java]
        viewModel.users.observe(viewLifecycleOwner, animalListDataObserver)
        viewModel.loading.observe(viewLifecycleOwner, loadingDataObserver)
        viewModel.loadError.observe(viewLifecycleOwner, errorObserver)
        viewModel.refresh()
       // listAdapter = user_list_adapter((requireContext())
        binding.userList.apply { layoutManager = GridLayoutManager(context, 2)
            adapter = listAdapter}
//        floatingActionButtonGoToDetail.setOnClickListener {
//            val action:NavDirections = ListFragmentDirections.actionListFragmentToDetailFragment();
//            Navigation.findNavController(it).navigate(action);
//
//        }
        binding.refreshLayout.setOnRefreshListener { binding.userList.visibility = View.GONE
            binding.listError.visibility = View.GONE
            binding.listViewProgressBar.visibility = View.GONE
            viewModel.refresh()
            binding.refreshLayout.isRefreshing=false}
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}