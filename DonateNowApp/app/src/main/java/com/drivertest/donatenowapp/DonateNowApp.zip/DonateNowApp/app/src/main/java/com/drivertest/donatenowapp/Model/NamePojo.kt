package com.drivertest.donatenowapp.Model

import androidx.room.Entity


data class NamePojo(val title:String?,val first:String?,val last:String?){
}